package com.zybooks.projecttwo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private EditText etItemName, etItemQuantity, etItemDate;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        etItemName = findViewById(R.id.Name);
        etItemQuantity = findViewById(R.id.Quantity);
        etItemDate = findViewById(R.id.DateEdited);
        btnSave = findViewById(R.id.buttonAddItem);

        btnSave.setOnClickListener(v -> {
            String name = etItemName.getText().toString().trim();
            String quantityStr = etItemQuantity.getText().toString().trim();
            String date = etItemDate.getText().toString().trim();

            if (name.isEmpty() || quantityStr.isEmpty() || date.isEmpty()) {
                Toast.makeText(AddItemActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity;
            try {
                quantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException e) {
                Toast.makeText(AddItemActivity.this, "Invalid quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save the item to the database
            DatabaseHelper dbHelper = new DatabaseHelper(AddItemActivity.this);
            long id = dbHelper.addItem(name, date, quantity);

            if (id != -1) {
                Toast.makeText(AddItemActivity.this, "Item added", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK); // Indicate success
                finish(); // Close the activity and return to InventoryActivity
            } else {
                Toast.makeText(AddItemActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
