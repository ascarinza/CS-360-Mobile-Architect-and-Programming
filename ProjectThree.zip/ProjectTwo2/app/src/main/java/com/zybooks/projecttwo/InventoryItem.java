package com.zybooks.projecttwo;

public class InventoryItem {
    private long id;
    private String name;
    private int quantity;
    private String date;

    public InventoryItem(long id, String name, int quantity, String date) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.date = date;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getDate() {
        return date;
    }

    public void setDate() { this.date = date;}
}
