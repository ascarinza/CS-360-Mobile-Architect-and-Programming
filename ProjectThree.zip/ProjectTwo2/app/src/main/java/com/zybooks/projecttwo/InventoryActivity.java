package com.zybooks.projecttwo;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private Button btnAdd;
    private RecyclerView recyclerView;
    private InventoryAdapter inventoryAdapter;
    private List<InventoryItem> inventoryItemList;
    private InventoryDBOperations dbOperations;
    private DatabaseHelper dbHelper;
    private List<InventoryItem> itemList;
    private InventoryAdapter adapter;
    private static final int ADD_ITEM_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Initialize views
        btnAdd = findViewById(R.id.buttonAdd);
        recyclerView = findViewById(R.id.recyclerView);
        itemList = new ArrayList<>();
        dbHelper = new DatabaseHelper(this);

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(this, itemList);
        recyclerView.setAdapter(adapter);

        loadInventoryItems();

        btnAdd.setOnClickListener(v -> {
            // Handle adding new items here
            Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
            startActivityForResult(intent, ADD_ITEM_REQUEST_CODE);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload items when returning from AddItemActivity
        loadItems();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_ITEM_REQUEST_CODE && resultCode == RESULT_OK) {
            // Reload items when returning from AddItemActivity
            loadItems();
        }
    }

    private void loadItems() {
        itemList.clear();
        itemList.addAll(dbHelper.getAllItems()); // Ensure you have a method to retrieve all items
        adapter.notifyDataSetChanged();
    }

    private void loadInventoryItems() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_ITEMS,
                null, null, null, null, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_ID));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                    String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_DATE));
                    int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_QUANTITY));
                    itemList.add(new InventoryItem(id, name, quantity, date));
                } while (cursor.moveToNext());
            }
            cursor.close();
            adapter.notifyDataSetChanged();
        } else {
            // Handle case where cursor is null
            Toast.makeText(this, "Error loading items", Toast.LENGTH_SHORT).show();
        }
    }
}