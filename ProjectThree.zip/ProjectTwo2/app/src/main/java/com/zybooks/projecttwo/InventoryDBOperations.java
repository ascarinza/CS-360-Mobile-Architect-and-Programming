package com.zybooks.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class InventoryDBOperations {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public InventoryDBOperations(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long addItem(String name, int quantity, String date) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, name);
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, quantity);
        return database.insert(DatabaseHelper.TABLE_ITEMS, null, values);
    }

    public void deleteItem(long id) {
        database.delete(DatabaseHelper.TABLE_ITEMS,
                DatabaseHelper.COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void updateItem(long id, String name, int quantity, String date) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, name);
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, quantity);
        values.put(DatabaseHelper.COLUMN_ITEM_DATE, date);

        database.update(DatabaseHelper.TABLE_ITEMS, values,
                DatabaseHelper.COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE_ITEMS, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                InventoryItem item = new InventoryItem(
                        cursor.getLong(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_ID)),
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_NAME)),
                        cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_QUANTITY)),
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_DATE))
                );
                items.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }
}